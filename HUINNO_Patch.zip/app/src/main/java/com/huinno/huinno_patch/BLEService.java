package com.huinno.huinno_patch;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.UUID;


/**
 * Created by Sunghoon on 2018. 2. 14..
 */

public class BLEService extends Service {
    private final static String TAG = BLEService.class.getSimpleName();

    private BluetoothManager bluetoothManager;
    private BluetoothAdapter bluetoothAdapter;
    private String bluetoothDeviceAddress;
    private BluetoothGatt bluetoothGatt;
    private BluetoothLeScanner scanner;
    private ScanSettings settings;
    private ScanCallback scanCallback;
    private ArrayList<BluetoothDevice> deviceList = new ArrayList<>();

    private boolean mScanning;

    private int connectionState = STATE_DISCONNECTED;

    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;

    public final static String ACTION_GATT_CONNECTED = "com.huinno.memo.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED = "com.huinno.memo.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_PAIRED = "com.huinno.memo.ACTION_GATT_PAIRED";
    public final static String ACTION_GATT_UNPAIRED = "com.huinno.memo.ACTION_GATT_UNPAIRED";
    public final static String ACTION_DEVICE_DISCOVERED = "com.huinno.memo.ACTION_DEVICE_DISCOVERED";
    public final static String ACTION_BP_META_REGISTERED = "com.huinno.memo.ACTION_BP_META_REGISTERED";
    public final static String ACTION_BP_RAW_UPLOADED = "com.huinno.memo.ACTION_BP_RAW_UPLOADED";
    public final static String ACTION_ECG_META_REGISTERED = "com.huinno.memo.ACTION_ECG_META_REGISTERED";
    public final static String ACTION_ECG_RAW_UPLOADED = "com.huinno.memo.ACTION_ECG_RAW_UPLOADED";
    public final static String ACTION_FIRMWARE_UPDATE = "com.huinno.memo.ACTION_FIRMWARE_UPDATE";
    public final static String ACTION_START_CALIBRATION = "com.huinno.memo.ACTION_START_CALIBRATION";
    public final static String ACTION_SKIP_CALIBRATION = "com.huinno.memo.ACTION_SKIP_CALIBRATION";
    public final static String ACTION_STABLE_CALIBRATION = "com.huinno.memo.ACTION_STABLE_CALIBRATION";
    public final static String ACTION_ACTIVE_CALIBRATION = "com.huinno.memo.ACTION_ACTIVE_CALIBRATION";
    public final static String ACTION_CALIBRATION_PROGRESS = "com.huinno.memo.ACTION_CALIBRATION_PROGRESS";
    public final static String ACTION_CALIBRATION_COMPLETE = "com.huinno.memo.ACTION_CALIBRATION_COMPLETE";

    public final static String ACTION_SIGNAL_RECEIVED = "com.huinno.memo.ACTION_SIGNAL_RECEIVED";

    public static UUID HUINNO_SERVICE_UUID = UUID.fromString("2dfc0001-2545-0454-3434-73615a9b34fa");
    public static UUID RAW_SIGNAL_SERVICE_UUID = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb");
    public static UUID DEVICE_INFORMATION_SERVICE_UUID = UUID.fromString("0000180a-0000-1000-8000-00805f9b34fb");

    public static UUID COMMAND_UUID = UUID.fromString("2dfc0002-2545-0454-3434-73615a9b34fa");
    public static UUID RAW_SIGNAL_UUID = UUID.fromString("0000fff4-0000-1000-8000-00805f9b34fb");
    public static UUID SERIAL_NUMBER_UUID = UUID.fromString("00002a25-0000-1000-8000-00805f9b34fb");
    public static UUID HARDWARE_REVISION_UUID = UUID.fromString("00002a27-0000-1000-8000-00805f9b34fb");
    public static UUID SOFTWARE_REVISION_UUID = UUID.fromString("00002a28-0000-1000-8000-00805f9b34fb");

    public static UUID CLIENT_CHARACTERISTIC_CONFIG = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    enum BLERequest {
        hCmdInit((byte)1),
        hCmdCheckCmdLinkEnable((byte)2),
        hCmdStartPairing((byte)3),
        hCmdCheckUnpairing((byte)4),
        hCmdStartUnpairing((byte)5),
        hCmdGetSyncState((byte)6),
        hCmdSendAccountInfo((byte)7),
        hCmdStartSync((byte)8),
        hCmdNotifySyncState((byte)9),
        hCmdStopSync((byte)10),
        hCmdInitIndex((byte)11),
        hCmdPairComplete((byte)12),
        hCmdStartCalibration((byte)13),
        hCmdStableCalibration((byte)14),
        hCmdLegLiftCalibration((byte)15),
        hCmdBatData((byte)16),
        hCmdSendFormula((byte)17),
        hCmdResetCalibration((byte)18),
        hCmdSkipCalibration((byte)19),
        hCmdIsCalibrated((byte)20),
        hCmdAck((byte)129),
        hCmdNack((byte)130),
        hCmdSyncAck((byte)131),
        hCmdSyncNack((byte)132);

        public byte value;
        private BLERequest(byte value) {
            this.value = value;
        }
    }

    class CharacteristicWrite {
        public BluetoothGattCharacteristic characteristic;
        public byte[] value;
        public CharacteristicWrite(BluetoothGattCharacteristic characteristic, byte[] value) {
            this.characteristic = characteristic;
            this.value = value;
        }
    }

    class DescriptorWrite {
        public BluetoothGattCharacteristic characteristic;
        public boolean enable;
        public DescriptorWrite(BluetoothGattCharacteristic characteristic, boolean enable) {
            this.characteristic = characteristic;
            this.enable = enable;
        }
    }

    private ArrayList<Float> ecgBuffer = new ArrayList<>();

    private HashMap<String, BluetoothGattCharacteristic> characteristics = new HashMap<>();

    private Queue<Object> writeQueue = new LinkedList<>();
    private boolean isWriting = false;

    public void writeFromQueue() {
        if (isWriting)
            return;
        if (writeQueue.size() == 0)
            return;

        isWriting = true;

        if (writeQueue.peek() instanceof DescriptorWrite) {
            DescriptorWrite descriptorWrite = (DescriptorWrite)writeQueue.poll();
            setCharacteristicNotification(descriptorWrite.characteristic, descriptorWrite.enable);
        } else if (writeQueue.peek() instanceof CharacteristicWrite) {
            CharacteristicWrite characteristicWrite = (CharacteristicWrite)writeQueue.poll();
            characteristicWrite.characteristic.setValue(characteristicWrite.value);
            bluetoothGatt.writeCharacteristic(characteristicWrite.characteristic);
        }
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connectionState = STATE_CONNECTED;
                Log.d(TAG, "Connected");
                gatt.discoverServices();
                broadcastUpdate(ACTION_GATT_CONNECTED);
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connectionState = STATE_DISCONNECTED;
                Log.d(TAG, "Disconnected");
                broadcastUpdate(ACTION_GATT_DISCONNECTED);
            } else if (newState == BluetoothProfile.STATE_CONNECTING) {
                connectionState = STATE_CONNECTING;
                Log.d(TAG, "Connecting");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
//                for (BluetoothGattCharacteristic characteristic : gatt.getService(HUINNO_SERVICE_UUID).getCharacteristics()) {
//                    Log.d(TAG, "Huinno Service discovered");
//                    if (characteristic.getUuid().equals(COMMAND_UUID)) {
//                        characteristics.put("Command", characteristic);
//
//                        writeQueue.add(new DescriptorWrite(characteristics.get("Command"), true));
//                        writeFromQueue();
//
//                        byte[] value = {BLERequest.hCmdCheckCmdLinkEnable.value};
//                        writeQueue.add(new CharacteristicWrite(characteristics.get("Command"), value));
//                        writeFromQueue();
//                    }
//                }

//                for (BluetoothGattCharacteristic characteristic : gatt.getService(DEVICE_INFORMATION_SERVICE_UUID).getCharacteristics()) {
//                    Log.d(TAG, "Device Information Service discovered");
//                    if (characteristic.getUuid().equals(SERIAL_NUMBER_UUID)) {
//                        characteristics.put("SerialNumber", characteristic);
//                    }
//                    if (characteristic.getUuid().equals(HARDWARE_REVISION_UUID)) {
//                        characteristics.put("HardwareVersion", characteristic);
//                    }
//                    if (characteristic.getUuid().equals(SOFTWARE_REVISION_UUID)) {
//                        characteristics.put("SoftwareVersion", characteristic);
//                    }
//                }

                for (BluetoothGattCharacteristic characteristic : gatt.getService(RAW_SIGNAL_SERVICE_UUID).getCharacteristics()) {
                    Log.d(TAG, "Raw Signal Service discovered");
                    if (characteristic.getUuid().equals(RAW_SIGNAL_UUID)) {
                        characteristics.put("RawSignal", characteristic);

                        writeQueue.add(new DescriptorWrite(characteristics.get("RawSignal"), true));
                        writeFromQueue();
                    }
                }
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (SERIAL_NUMBER_UUID.equals(characteristic.getUuid())) {
                    String value = new String(characteristic.getValue());
                    Log.d(TAG, "SERIAL NUMBER: " + value);
                    SharedPreferences preferences = getSharedPreferences("user", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("SerialNumber", value);
                    editor.commit();
                    readCharacteristic(characteristics.get("HardwareVersion"));
                } else if (HARDWARE_REVISION_UUID.equals(characteristic.getUuid())) {
                    String value = new String(characteristic.getValue());
                    Log.d(TAG, "HARDWARE VERSION: " + value);
                    SharedPreferences preferences = getSharedPreferences("user", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("HardwareVersion", value);
                    editor.commit();
                    readCharacteristic(characteristics.get("SoftwareVersion"));
                } else if (SOFTWARE_REVISION_UUID.equals(characteristic.getUuid())) {
                    String value = new String(characteristic.getValue());
                    Log.d(TAG, "SOFTWARE VERSION: " + value);
                    SharedPreferences preferences = getSharedPreferences("user", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("SoftwareVersion", value);
                    editor.commit();

                    byte[] packet = {BLERequest.hCmdSendAccountInfo.value, 0, 0};
                    writeQueue.add(new CharacteristicWrite(characteristics.get("Command"), packet));
                    writeFromQueue();
                }
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(TAG, "Characteristic write");
                isWriting = false;
                writeFromQueue();
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(TAG, "Descriptor write");
                isWriting = false;
                writeFromQueue();
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            if (COMMAND_UUID.equals(characteristic.getUuid())) {
                byte[] value = characteristic.getValue();
                byte header;
                byte opCode = 0;
                header = value[0];
                if (value.length > 1) {
                    opCode = value[1];
                }
                if (header == BLERequest.hCmdAck.value) {
                    if (opCode == BLERequest.hCmdCheckCmdLinkEnable.value) {
                        if (bluetoothAdapter.getBondedDevices().size() > 0) {
                            broadcastUpdate(ACTION_GATT_PAIRED);
                            startInitiation();
                        } else {
                            Log.d(TAG, "Start pairing");
                            byte[] packet = { BLERequest.hCmdStartPairing.value };
                            writeQueue.add(new CharacteristicWrite(characteristic, packet));
                            writeFromQueue();
                        }
                    } else if (opCode == BLERequest.hCmdStartPairing.value) {
                        // Connection complete routine after pass code exchange
                        Log.d(TAG, "Paired");
                        connectionState = STATE_CONNECTED;
                        broadcastUpdate(ACTION_GATT_PAIRED);
                        readCharacteristic(characteristics.get("SerialNumber"));
                    } else if (opCode == BLERequest.hCmdCheckUnpairing.value) {
                        byte[] packet = { BLERequest.hCmdStartUnpairing.value };
                        characteristic.setValue(packet);
                        gatt.writeCharacteristic(characteristic);
                    } else if (opCode == BLERequest.hCmdStartUnpairing.value) {
                        unpair();
                    }
                } else if (header == BLERequest.hCmdNack.value) {
                    if (opCode == BLERequest.hCmdStartPairing.value) {
                        broadcastUpdate(ACTION_GATT_PAIRED);
                    }
                }
            } else if (RAW_SIGNAL_UUID.equals(characteristic.getUuid())) {
                ecgBuffer.clear();
                byte[] value = characteristic.getValue();
                for (int i=0 ; i<value.length / 4 ; i++) {
                    ecgBuffer.add(ByteBuffer.wrap(value, i * 4, 4).order(ByteOrder.LITTLE_ENDIAN).getFloat());
                }
                Intent intent = new Intent(ACTION_SIGNAL_RECEIVED);
                intent.putExtra("signal", ecgBuffer);
                sendBroadcast(intent);
            }
        }
    };

    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        if (ACTION_GATT_CONNECTED.equals(action) || ACTION_GATT_PAIRED.equals(action)) {
            intent.putExtra("name", bluetoothGatt.getDevice().getName());
        } else if (ACTION_DEVICE_DISCOVERED.equals(action)) {
            intent.putExtra("deviceList", deviceList);
        }
        sendBroadcast(intent);
    }

    private void broadcastUpdate(final String action, String data) {
        final Intent intent = new Intent(action);
        if (ACTION_BP_RAW_UPLOADED.equals(action)) {
            intent.putExtra("bpKey", data);
        } else if (ACTION_ECG_RAW_UPLOADED.equals(action)) {
            intent.putExtra("ecgKey", data);
        } else if (ACTION_FIRMWARE_UPDATE.equals(action)) {
            intent.putExtra("progress", data);
        } else if (ACTION_CALIBRATION_PROGRESS.equals(action)) {
            intent.putExtra("progress", data);
        } else if (ACTION_CALIBRATION_COMPLETE.equals(action)) {
            intent.putExtra("type", data);
        }
        sendBroadcast(intent);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }

    public class LocalBinder extends Binder {
        BLEService getService() {
            return BLEService.this;
        }
    }

    private final IBinder binder = new LocalBinder();

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        close();
        return super.onUnbind(intent);
    }

    public boolean initialize() {
        deviceList.clear();

        // For API level 18 and above, get a reference to BluetoothAdapter through BluetoothManager.
        if (bluetoothManager == null) {
            bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (bluetoothManager == null) {
                return false;
            }
        }

        bluetoothAdapter = bluetoothManager.getAdapter();
        if (bluetoothAdapter == null) {
            return false;
        }

        settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_BALANCED).build();
        scanCallback = new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                boolean exist = false;
                for (BluetoothDevice d : deviceList) {
                    if (d.getAddress().equals(device.getAddress())) {
                        exist = true;
                        break;
                    }
                }
                if (!exist) {
                    deviceList.add(device);
                    broadcastUpdate(ACTION_DEVICE_DISCOVERED);
                }
            }

            @Override
            public void onBatchScanResults(List<ScanResult> results) {
                for (ScanResult result : results) {
                    BluetoothDevice device = result.getDevice();
                    boolean exist = false;
                    for (BluetoothDevice d : deviceList) {
                        if (d.getAddress().equals(device.getAddress())) {
                            exist = true;
                            break;
                        }
                    }
                    if (!exist) {
                        deviceList.add(device);
                        broadcastUpdate(ACTION_DEVICE_DISCOVERED);
                    }
                }
            }
        };

        scanner = bluetoothAdapter.getBluetoothLeScanner();

        return true;
    }

    public boolean connect(final String address) {
        if (bluetoothAdapter == null || address == null) {
            return false;
        }

        // Previously connected device.  Try to reconnect.
        if (bluetoothDeviceAddress != null && address.equals(bluetoothDeviceAddress) && bluetoothGatt != null) {
            if (bluetoothGatt.connect()) {
                connectionState = STATE_CONNECTING;
                return true;
            } else {
                return false;
            }
        }

        final BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
        if (device == null) {
            return false;
        }

        if (device.getName() != null && (device.getName().contains("MEMO")))
            bluetoothGatt = BLEUtil.getInstance(this).connectGatt(device, true, gattCallback);
            //bluetoothGatt = device.connectGatt(this, true, gattCallback, BluetoothDevice.TRANSPORT_LE);
        else
            bluetoothGatt = BLEUtil.getInstance(this).connectGatt(device, false, gattCallback);
            //bluetoothGatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        //bluetoothGatt = device.connectGatt(this, false, gattCallback);

        bluetoothDeviceAddress = address;
        connectionState = STATE_CONNECTING;

        SharedPreferences preferences = getSharedPreferences("user", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("DeviceAddress", bluetoothDeviceAddress);
        editor.commit();
        return true;
    }

    public void disconnect() {
        if (bluetoothAdapter == null || bluetoothGatt == null) {
            return;
        }
        bluetoothGatt.disconnect();
    }

    public void close() {
        if (bluetoothGatt == null) {
            return;
        }
        bluetoothGatt.close();
        bluetoothGatt = null;
    }

    public void readCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (bluetoothAdapter == null || bluetoothGatt == null) {
            return;
        }
        bluetoothGatt.readCharacteristic(characteristic);
    }

    public void writeCommandCharacteristic(byte[] packet) {
        if (bluetoothAdapter == null || bluetoothGatt == null) {
            return;
        }
        writeQueue.add(new CharacteristicWrite(characteristics.get("Command"), packet));
        writeFromQueue();
    }

    public void setCharacteristicNotification(BluetoothGattCharacteristic characteristic, boolean enabled) {
        if (bluetoothAdapter == null || bluetoothGatt == null) {
            return;
        }
        bluetoothGatt.setCharacteristicNotification(characteristic, enabled);

        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG);
        if (descriptor != null) {
            descriptor.setValue(enabled ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
            bluetoothGatt.writeDescriptor(descriptor);
        }
    }

    public List<BluetoothGattService> getSupportedGattServices() {
        if (bluetoothGatt == null) return null;

        return bluetoothGatt.getServices();
    }

    public BluetoothManager getBluetoothManager() {
        return bluetoothManager;
    }

    public BluetoothGatt getBluetoothGatt() {
        return bluetoothGatt;
    }

    public BluetoothAdapter getBluetoothAdapter() {
        return bluetoothAdapter;
    }

    public void startScan() {
        Log.d(TAG, "Start scan");
        deviceList.clear();
        List<ScanFilter> filters = new ArrayList<>();
        scanner.startScan(filters, settings, scanCallback);
        mScanning = true;
    }

    public void stopScan() {
        Log.d(TAG, "Stop scan");
        scanner.stopScan(scanCallback);
        mScanning = false;
    }

    public void refreshScan() {
        deviceList.clear();

        if (mScanning) {
            stopScan();
        }
        mScanning = true;
        startScan();
    }

    public void checkUnpair() {
        if (characteristics.get("Command") != null) {
            byte[] packet = {BLERequest.hCmdCheckUnpairing.value};
            writeQueue.add(new CharacteristicWrite(characteristics.get("Command"), packet));
            writeFromQueue();
        }
    }

    public void unpair() {
        disconnect();

        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                try {
                    Method m = device.getClass().getMethod("removeBond", (Class[]) null);
                    m.invoke(device, (Object[]) null);
                } catch (Exception e) {
                    Log.e("fail", e.getMessage());
                }
            }
        }
        broadcastUpdate(ACTION_GATT_UNPAIRED);
        close();

        SharedPreferences preferences = getSharedPreferences("user", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.remove("DeviceAddress");
        editor.remove("HardwareVersion");
        editor.remove("SoftwareVersion");
        editor.remove("SerialNumber");
        editor.remove("syncBPMetaIndex");
        editor.remove("syncCalibrationMetaIndex");
        editor.remove("syncReferenceMetaIndex");
        editor.remove("syncECGMetaIndex");
        editor.remove("formulaSA");
        editor.remove("formulaSB");
        editor.remove("formulaDA");
        editor.remove("formulaDB");
        editor.commit();

        isWriting = false;
        writeQueue.clear();
    }

    public void startInitiation() {
        sendDataPacket();
        byte[] packet = {BLERequest.hCmdGetSyncState.value};
        writeQueue.add(new CharacteristicWrite(characteristics.get("Command"), packet));
        writeFromQueue();
    }

    public void sendDataPacket() {
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        SimpleDateFormat format = new SimpleDateFormat("yyyy MM dd HH mm ss");
        String dateString = format.format(date);
        StringTokenizer tokenizer = new StringTokenizer(dateString, " ");

        int year = Integer.valueOf(tokenizer.nextToken()) - 2000;
        int month = Integer.valueOf(tokenizer.nextToken());
        int day = Integer.valueOf(tokenizer.nextToken());
        int hour = Integer.valueOf(tokenizer.nextToken());
        int minute = Integer.valueOf(tokenizer.nextToken());
        int second = Integer.valueOf(tokenizer.nextToken());
        int timeZoneIndex = getTimeZoneIndex();

        Calendar calendar = Calendar.getInstance();
        int weekday = calendar.get(Calendar.DAY_OF_WEEK);
        weekday -= 1;
        if (weekday == 0) {
            weekday = 7;
        }

        byte[] packet = {BLERequest.hCmdInit.value, (byte)year, (byte)month, (byte)day, (byte)weekday, (byte)hour, (byte)minute, (byte)second, (byte)(timeZoneIndex >>> 8), (byte)(timeZoneIndex & 0xff)};
        writeQueue.add(new CharacteristicWrite(characteristics.get("Command"), packet));
        writeFromQueue();
    }

    public int getTimeZoneIndex() {
        int offset = TimeZone.getDefault().getRawOffset() / 1000 + 43200;
        double offsetIndex = offset / 900.0;
        return (int)offsetIndex;
    }
}
