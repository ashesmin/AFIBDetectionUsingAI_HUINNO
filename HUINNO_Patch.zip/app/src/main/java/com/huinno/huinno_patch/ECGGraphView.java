package com.huinno.huinno_patch;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import java.util.ArrayList;

/**
 * Created by Sunghoon on 2018. 2. 26..
 */

public class ECGGraphView extends View {
    private Context context;
    private ArrayList<Float> ecgData;
    private int singleGridPxSize;
    private float freq = 250.0f;

    public ECGGraphView(Context context) {
        super(context);
        this.context = context;
        init(null, 0);
    }

    public ECGGraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        init(attrs, 0);
    }

    public ECGGraphView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.context = context;
        init(attrs, defStyle);
    }

    private void init(AttributeSet attrs, int defStyle) {
        singleGridPxSize = (int)Utils.dpToPx(5, context);
    }

    public void setData(ArrayList<Float> ecgData) {
        this.ecgData = ecgData;
        setLayoutParams(new LinearLayout.LayoutParams((ecgData.size() / (int)freq) * 5 * 5 * singleGridPxSize, (int) Utils.dpToPx(750, context)));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        drawGrid(canvas);
        //drawUnit(canvas);
        drawGraph(canvas);
    }

    private void drawGrid(Canvas canvas) {
        canvas.drawColor(Color.WHITE);

        Paint paint = new Paint();
        paint.setStrokeWidth(1);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.argb(150, 200, 80, 80));

        Paint boldPaint = new Paint();
        boldPaint.setStrokeWidth(2);
        boldPaint.setStyle(Paint.Style.STROKE);
        boldPaint.setColor(Color.argb(150, 200, 80, 80));

        // Horizontal lines
        for (int i=0 ; i<=150 ; i++) {
            if (i % 5 == 0) {
                canvas.drawLine(100, i * singleGridPxSize, this.getWidth(), i * singleGridPxSize, boldPaint);
            } else {
                canvas.drawLine(100, i * singleGridPxSize, this.getWidth(), i * singleGridPxSize, paint);
            }
        }

        // Vertical lines
        for (int i=0 ; i<Utils.pxToDp(this.getWidth(), context) ; i++) {
            if (i % 5 == 0) {
                //bold
                canvas.drawLine(i * singleGridPxSize + 100, 0, i * singleGridPxSize +100, 150 * singleGridPxSize /*Utils.dpToPx(300, context)*/, boldPaint);
            } else {
                canvas.drawLine(i * singleGridPxSize + 100, 0, i * singleGridPxSize + 100, 150 * singleGridPxSize /*Utils.dpToPx(300, context)*/, paint);
            }
        }
    }

    private void drawUnit(Canvas canvas) {
        Paint paint = new Paint();
        paint.setStrokeWidth(5);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.BLACK);

        Path path = new Path();
        path.moveTo(2.5f * singleGridPxSize, 40 * singleGridPxSize);
        path.lineTo(5 * singleGridPxSize, 40 * singleGridPxSize);
        path.lineTo(5 * singleGridPxSize, 30 * singleGridPxSize);
        path.lineTo(10 * singleGridPxSize, 30 * singleGridPxSize);
        path.lineTo(10 * singleGridPxSize, 40 * singleGridPxSize);
        path.lineTo(12.5f * singleGridPxSize, 40 * singleGridPxSize);

        canvas.drawPath(path, paint);

        Paint textPaint = new Paint();
        textPaint.setStrokeWidth(1);
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setColor(Color.DKGRAY);
        textPaint.setTextSize(30);
        textPaint.setTextAlign(Paint.Align.CENTER);

        canvas.drawText("1 mV", 7.5f * singleGridPxSize, 43 * singleGridPxSize, textPaint);

        textPaint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("25 mm/s, 10 mm/mV", singleGridPxSize, 2 * singleGridPxSize, textPaint);

        for (int i=0 ; i<30 ; i++) {
            canvas.drawText(String.valueOf(i), (25 + 25 * i) * singleGridPxSize,60 * singleGridPxSize, textPaint);
        }

    }

    private void drawGraph(Canvas canvas) {
        if (ecgData.size() == 0)
            return;

        Paint paint = new Paint();
        paint.setStrokeWidth(5);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.BLACK);

        for (int i=1 ; i<ecgData.size() ; i++) {
            float prevValue = ecgData.get(i-1);
            float curValue = ecgData.get(i);

            float prevX = (singleGridPxSize * 5 * 5 / freq) * (i-1) + 100;
            float prevY = 70 * singleGridPxSize - prevValue * singleGridPxSize * 10;

            float curX = (singleGridPxSize * 5 * 5 / freq) * i + 100;
            float curY = 70 * singleGridPxSize - curValue * singleGridPxSize * 10;

            canvas.drawLine(prevX, prevY, curX, curY, paint);
        }
    }
}
