package com.huinno.huinno_patch;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class PairingActivity extends AppCompatActivity {
    private final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 100;
    private RecyclerView rvPairing;

    private ArrayList<BluetoothDevice> deviceList;

    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BLEService.ACTION_DEVICE_DISCOVERED.equals(action)) {
                deviceList.clear();
                deviceList.addAll((ArrayList<BluetoothDevice>)intent.getSerializableExtra("deviceList"));
                rvPairing.getAdapter().notifyDataSetChanged();
            }
            if (HUINNO_Patch.ACTION_SERVICE_CONNECTED.equals(action)) {
                ((HUINNO_Patch)getApplication()).getBLEService().startScan();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pairing);

        deviceList = new ArrayList<>();

        rvPairing = findViewById(R.id.rvPairing);
        rvPairing.setLayoutManager(new LinearLayoutManager(this));
        rvPairing.setAdapter(new PairingListAdapter(this, deviceList));

        int permissionCheck = ContextCompat.checkSelfPermission(PairingActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION);
        ActivityCompat.requestPermissions(PairingActivity.this,
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                MY_PERMISSIONS_REQUEST_READ_CONTACTS);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_READ_CONTACTS: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
        rvPairing.getAdapter().notifyDataSetChanged();
        if (((HUINNO_Patch)getApplication()).getBLEService() != null) {
            ((HUINNO_Patch) getApplication()).getBLEService().startScan();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mGattUpdateReceiver);
        if (((HUINNO_Patch)getApplication()).getBLEService() != null) {
            ((HUINNO_Patch) getApplication()).getBLEService().stopScan();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.pairing_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.action_refresh:
//                deviceList.clear();
//                rvPairing.getAdapter().notifyDataSetChanged();
//                ((MEMO)getApplication()).getBLEService().refreshScan();
//                break;
//            case R.id.action_skip:
//                AlertDialog.Builder builder = new AlertDialog.Builder(this)
//                        .setTitle("Skip Pairing")
//                        .setMessage("Do you want to skip pairing with your watch?\nYou can pair later in Settings page.")
//                        .setPositiveButton("Skip", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                Intent intent = new Intent(PairingActivity.this, MainActivity.class);
//                                startActivity(intent);
//                                finish();
//                            }
//                        })
//                        .setNegativeButton("Cancel", null);
//                builder.create().show();
//                break;
//        }
        return true;
    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BLEService.ACTION_DEVICE_DISCOVERED);
        return intentFilter;
    }
}

class PairingListAdapter extends RecyclerView.Adapter<PairingListAdapter.ItemViewHolder> {
    private Context context;
    private ArrayList<BluetoothDevice> list;

    public PairingListAdapter(Context context, ArrayList<BluetoothDevice> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public PairingListAdapter.ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_title_detail_item, parent, false);
        return new PairingListAdapter.ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PairingListAdapter.ItemViewHolder holder, int position) {
        final int pos = position;
        if (list.get(position).getName() != null)
            holder.tvTitle.setText(list.get(position).getName());
        else
            holder.tvTitle.setText("-");
        holder.tvDetail.setText(list.get(position).getAddress());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ECGDetailActivity.class);
                intent.putExtra("device", list.get(pos));
                context.startActivity(intent);
                list.clear();
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class ItemViewHolder extends RecyclerView.ViewHolder {
        private TextView tvTitle;
        private TextView tvDetail;

        public ItemViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDetail = itemView.findViewById(R.id.tvDetail);
            tvTitle.setTextColor(Color.WHITE);
            tvDetail.setTextColor(Color.WHITE);
        }
    }
}