package com.huinno.huinno_patch;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class ECGDetailActivity extends AppCompatActivity {
    private final static String TAG = ECGDetailActivity.class.getSimpleName();

    private BluetoothDevice device;

    private ECGGraphView graph;
    private ArrayList<Float> ecgData = new ArrayList<>();
    private int header = 0;

    private int totalLength = 750;

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BLEService.ACTION_SIGNAL_RECEIVED);
        return intentFilter;
    }

    private final BroadcastReceiver mUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BLEService.ACTION_SIGNAL_RECEIVED.equals(action)) {
                ArrayList<Float> temp = (ArrayList<Float>)intent.getSerializableExtra("signal");
                ecgData.subList(header, header + temp.size()).clear();
                ecgData.addAll(header, temp);
                header += temp.size();
                if (header >= totalLength) {
                    header = 0;
                }
                graph.setData(ecgData);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecgdetail);

        device = getIntent().getParcelableExtra("device");
        if (((HUINNO_Patch)getApplication()).getBLEService().connect(device.getAddress())) {
            Log.d(TAG, "Connect: " + device.getName());
        } else {
            Log.d(TAG, "Connection fail: " + device.getName());
        }

        graph = findViewById(R.id.ecgGraph);

        for (int i=0 ; i < totalLength ; i++)
            ecgData.add(0f);
        graph.setData(ecgData);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mUpdateReceiver, makeGattUpdateIntentFilter());
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mUpdateReceiver);
    }
}
