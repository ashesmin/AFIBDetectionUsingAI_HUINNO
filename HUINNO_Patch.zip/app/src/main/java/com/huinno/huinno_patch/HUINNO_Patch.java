package com.huinno.huinno_patch;

import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

/**
 * Created by Sunghoon on 2018. 2. 14..
 */

public class HUINNO_Patch extends Application {
    private static Context appContext;

    private static BLEService mBluetoothLeService;
    public final static String ACTION_SERVICE_CONNECTED = "com.huinno.memo.ACTION_SERVICE_CONNECTED";

    // Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BLEService.LocalBinder) service).getService();
            if (mBluetoothLeService.initialize()) {
//                final Intent intent = new Intent(ACTION_SERVICE_CONNECTED);
//                sendBroadcast(intent);
                getBLEService().startScan();
            } else {
                Log.d("BLE", "Initialization failed");
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        appContext = this;

        Intent gattServiceIntent = new Intent(this, BLEService.class);
        startService(gattServiceIntent);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        unbindService(mServiceConnection);
        mBluetoothLeService = null;
    }

    public static Context getAppContext() {
        return appContext;
    }

    public static BLEService getBLEService() {
        return mBluetoothLeService;
    }
}
