
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __NANDFLASH_H
#define __NANDFLASH_H

/* Includes ------------------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32f0xx_hal.h"
#include "main.h"

/* USER CODE END Includes */

/* Private define ------------------------------------------------------------*/
#define WRITE_ENABLE    (1)
#define WRITE_DISABLE   (2)

#define BLOCK_BITS      (11)
#define PAGE_BITS       (6)
#define COLUMN_BITS     (13)

#define ERS_F_BITS      (4)     // 0b 0000 0100
#define WEL_BITS        (2)     // 0b 0000 0010
#define OIP_BITS        (1)     // 0b 0000 0001

#define BlockAddr_BITMASK(addr)         (addr & 0x07FF)
#define PageAddr_BITMASK(addr)          (addr & 0x3F)
#define ColumnAddr_BITMASK(addr)        (addr & 0x1FFF)
/* Public Function -----------------------------------------------------------*/
extern void NandFlash_TestFlow(void);
extern void Read_ChipID(void);
extern void Erase_Block(uint16_t blockAddr, uint8_t pageAddr, uint16_t columnAddr);
extern void Write_Data(uint16_t blockAddr, uint8_t pageAddr, uint16_t columnAddr, uint8_t *array, uint16_t length);
extern void Read_Data(uint16_t blockAddr, uint8_t pageAddr, uint16_t columnAddr, uint8_t *array, uint16_t length);
extern void Read_CellArray(uint16_t blockAddr, uint8_t pageAddr);
extern void Program_Load(uint16_t columnAddr, uint8_t *data, uint16_t length);
extern void Program_Excute(uint16_t blockAddr, uint8_t pageAddr);
extern void Write_Enable_Disable(uint8_t option);
extern void SPI_WriteRead(uint8_t *writeArray, uint16_t writeLength, uint8_t *readArray, uint16_t readLength);
extern uint8_t Get_Feature(uint8_t statusAddr);
extern uint8_t Set_Feature(uint8_t statusAddr, uint8_t setData);
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */


#endif /* __NANDFLASH_H */