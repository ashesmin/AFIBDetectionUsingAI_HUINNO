#include "NandFlash.h"

extern SPI_HandleTypeDef hspi1;

void NandFlash_TestFlow(void)
{
  /*
    // 2019-02-26 Nand-Flash Program TEST
  */
  uint8_t readBuffer[20] = {0x00,};
  memset(&readBuffer, 0x00, sizeof(readBuffer));
  
  Read_ChipID();
  Set_Feature(0xA0, 0x00); 
  Get_Feature(0xA0);
  Erase_Block(0, 0, NULL);
  
  Write_Data(0,0,0, "First_Message", 13);
  Read_Data(0,0,0, readBuffer, 13);
  
  while(1);
}

void Read_ChipID(void)
{
  uint8_t txArray[2] = {0x9F, 0x00};
  uint8_t rxArray[2] = {0x00, 0x00};
  
  SPI_WriteRead(txArray, 2, rxArray, 2);
}

/*
*       blockAddr       : max 2048, 11bits
*       pageAddr        : max 64, 6bits
*       columnAddr      : max 4224 or 4352 bytes/page , 13bits
*/
void Erase_Block(uint16_t blockAddr, uint8_t pageAddr, uint16_t columnAddr)
{
  uint8_t writeArray[10] = {0x00,};
  uint32_t address = 0;
  
  address = (BlockAddr_BITMASK(blockAddr) << BLOCK_BITS) | (PageAddr_BITMASK(pageAddr) << PAGE_BITS);
  
  Write_Enable_Disable(WRITE_ENABLE);
  while( !(Get_Feature(0xC0) & WEL_BITS) );
  
  writeArray[0] = 0xD8;         // BlockErase Command
  writeArray[1] = BREAK_UINT32(address, 2);
  writeArray[2] = BREAK_UINT32(address, 1);
  writeArray[3] = BREAK_UINT32(address, 0);
  SPI_WriteRead(writeArray, 4, NULL, 0);
  
  while( Get_Feature(0xC0) & OIP_BITS );
}

void Write_Data(uint16_t blockAddr, uint8_t pageAddr, uint16_t columnAddr, uint8_t *array, uint16_t length)
{
  Write_Enable_Disable(WRITE_ENABLE);
  while( !(Get_Feature(0xC0) & WEL_BITS) );
  
  Program_Load(columnAddr, array, length);
  Program_Excute(blockAddr, pageAddr);
  
  while( Get_Feature(0xC0) & OIP_BITS );
}

void Read_Data(uint16_t blockAddr, uint8_t pageAddr, uint16_t columnAddr, uint8_t *array, uint16_t length)
{
  uint8_t writeData[1+2] = {0x00,};
  memset(&writeData, 0x00, sizeof(writeData));
  
  Read_CellArray(blockAddr, pageAddr);
  while( Get_Feature(0xC0) & OIP_BITS );
  
  
  writeData[0] = 0x03;
  writeData[1] = HI_UINT16(columnAddr & 0x3FFF);
  writeData[2] = LO_UINT16(columnAddr & 0x3FFF);
  SPI_WriteRead(writeData, 3, array, length);
}

void Read_CellArray(uint16_t blockAddr, uint8_t pageAddr)
{
  uint8_t writeArray[10] = {0x00,};
  uint32_t address = 0;
  
  address = (BlockAddr_BITMASK(blockAddr) << BLOCK_BITS) | (PageAddr_BITMASK(pageAddr) << PAGE_BITS);
  
  writeArray[0] = 0x13;         // BlockErase Command
  writeArray[1] = BREAK_UINT32(address, 2);
  writeArray[2] = BREAK_UINT32(address, 1);
  writeArray[3] = BREAK_UINT32(address, 0);
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_RESET);
  
  HAL_SPI_Transmit(&hspi1,      writeArray,     4,    0xff);
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_SET);
}

// option -> 1(Enable), option -> 2(Disable)
void Write_Enable_Disable(uint8_t option)
{
  uint8_t cmd = 0x00;
  if(option == 1)
  {
    cmd = 0x06;
    SPI_WriteRead(&cmd, 1, NULL, 0);
  }
  else if(option == 2)
  {
    cmd = 0x04;
    SPI_WriteRead(&cmd, 1, NULL, 0);
  }
}

void Program_Load(uint16_t columnAddr, uint8_t *data, uint16_t length)
{
  uint8_t writeData[1+2] = {0x00,};
  memset(&writeData, 0x00, sizeof(writeData));
  
  writeData[0] = 0x02;
  writeData[1] = HI_UINT16(columnAddr & 0x3FFF);
  writeData[2] = LO_UINT16(columnAddr & 0x3FFF);
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_RESET);
  
  HAL_SPI_Transmit(&hspi1,      writeData,      3,      0xff);
  HAL_SPI_Transmit(&hspi1,      data,           length, 0xff);
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_SET);
}

void Program_Excute(uint16_t blockAddr, uint8_t pageAddr)
{
  uint8_t writeArray[10] = {0x00,};
  uint32_t address = 0;
  
  address = (BlockAddr_BITMASK(blockAddr) << BLOCK_BITS) | (PageAddr_BITMASK(pageAddr) << PAGE_BITS);
  
  writeArray[0] = 0x10;         // BlockErase Command
  writeArray[1] = BREAK_UINT32(address, 2);
  writeArray[2] = BREAK_UINT32(address, 1);
  writeArray[3] = BREAK_UINT32(address, 0);
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_RESET);
  
  HAL_SPI_Transmit(&hspi1,      writeArray,     4,    0xff);
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_SET);
  
}

void SPI_WriteRead(uint8_t *writeArray, uint16_t writeLength, uint8_t *readArray, uint16_t readLength)
{
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_RESET);
  
  HAL_SPI_Transmit(&hspi1,      writeArray,     writeLength,    0xff);
  if(readLength != 0)
    HAL_SPI_Receive(&hspi1,       readArray,      readLength,     0xff);
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_SET);
}

uint8_t Get_Feature(uint8_t statusAddr)
{
  uint8_t writeArray[2] = {0x00,0x00};
  uint8_t readByte = 0x00;
  
  writeArray[0] = 0x0F;
  writeArray[1] = statusAddr;
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_RESET);
  
  HAL_SPI_Transmit(&hspi1,      writeArray,     2,      0xff);
  HAL_SPI_Receive(&hspi1,       &readByte,      1,      0xff);
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_SET);
  
  return readByte;
}

uint8_t Set_Feature(uint8_t statusAddr, uint8_t setData)
{
  uint8_t writeArray[3] = {0x00,0x00,0x00};
  
  writeArray[0] = 0x1F;
  writeArray[1] = statusAddr;
  writeArray[2] = setData;
  
  Write_Enable_Disable(WRITE_ENABLE);
  while( !(Get_Feature(0xC0) & WEL_BITS) );
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_RESET);
  
  HAL_SPI_Transmit(&hspi1,      writeArray,     3,    0xff);
  
  HAL_GPIO_WritePin(SPI1_DF_CS1_GPIO_Port, SPI1_DF_CS1_Pin, GPIO_PIN_SET);
  
  while( Get_Feature(0xC0) & OIP_BITS );
  
  return setData;
}